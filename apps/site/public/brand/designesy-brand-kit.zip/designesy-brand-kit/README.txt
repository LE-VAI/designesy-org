Designesy brand kit

svg/  Vector masters. Use these wherever you can.
png/  Raster copies for places that need an image file.

Lockup: the mark plus the wordmark. Use the small lockup when the mark is 48px tall or less.
Ink files are for light backgrounds, white files for dark ones.
Keep clear space equal to the dot's diameter on every side.
The dot is Azure #0A94FF. Don't recolour, stretch, crop or re-type the logo.

Use these files to refer to Designesy, for example in an article, a talk, or an integration.
Don't use them to suggest that Designesy endorses or sponsors you.
For any other use, write to us first.

https://www.designesy.org/brand
